El **huito (*Genipa americana*)** is a species of trees in the family Rubiaceae. It is a species native from the tropical forests of North and South America.

Es usado por los nativos de la amazonia para teñir y pintarse el cuerpo por sus propiedades de colorante.

![Indigena haciendo uso del huito para realizar el diseño en su cuerpo](img_0.jpg){#fig:id.bl2tuxtg6f7n}

Adicionalmente el fruto se consume como fruta o macerado en aguardiente y se la atribuyen propiedades contra el asma



